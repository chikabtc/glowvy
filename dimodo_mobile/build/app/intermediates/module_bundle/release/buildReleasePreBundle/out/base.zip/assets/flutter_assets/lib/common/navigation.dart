
class Navs {
  static const subCategory = "sub_category";
    static const category = "category";
}